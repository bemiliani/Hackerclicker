// Version V1.3
let totalBytes = 0;
let bytesPerClick = 1;
let bytesPerSecond = 0;
let buyMultiplier = 1;

let upgrades = {
    miner: { count: 0, cost: 15, power: 1, baseCost: 15, costMultiplier: 1.2, id: "buy-miner-btn", label: "Background Script" },
    trojan: { count: 0, cost: 1000, power: 5, baseCost: 1000, costMultiplier: 1.2, id: "buy-trojan-btn", label: "Trojan Horse" },
    ransomware: { count: 0, cost: 5000, power: 40, baseCost: 5000, costMultiplier: 1.2, id: "buy-ransomware-btn", label: "Ransomware" },
    bootSector: { count: 0, cost: 9500, power: 200, baseCost: 2500, costMultiplier: 1.2, id: "buy-boot-btn", label: "Boot Sector Virus" },
    fileVirus: { count: 0, cost: 20000, power: 900, baseCost: 10000, costMultiplier: 1.2, id: "buy-file-btn", label: "File Virus" },
    macroVirus: { count: 0, cost: 50000, power: 4000, baseCost: 50000, costMultiplier: 1.2, id: "buy-macro-btn", label: "Macro Virus" },
    residentVirus: { count: 0, cost: 1000000, power: 18000, baseCost: 1000000, costMultiplier: 1.2, id: "buy-resident-btn", label: "Resident Virus" },
    multipartite: { count: 0, cost: 5000000, power: 85000, baseCost: 5000000, costMultiplier: 1.2, id: "buy-multipartite-btn", label: "Multipartite Virus" },
    polymorphic: { count: 0, cost: 10000000, power: 450000, baseCost: 10000000, costMultiplier: 1.2, id: "buy-polymorphic-btn", label: "Polymorphic Virus" }
};

let clickUpgradeCost = 50;
let clickUpgradeCount = 0;

const dataCounterDisplay = document.getElementById("data-counter");
const bpsCounterDisplay = document.getElementById("bps-counter");
const clickButton = document.getElementById("click-btn");
const upgradeClickButton = document.getElementById("upgrade-click-btn");
const clickUpgradeCostDisplay = document.getElementById("click-upgrade-cost");
const saveButton = document.getElementById("save-btn");
const loadButton = document.getElementById("load-btn");
const resetButton = document.getElementById("reset-btn");
const saveNameInput = document.getElementById("save-name-input");
const saveSelect = document.getElementById("save-select");
const consoleLog = document.getElementById("console-log");

const SAVE_LIST_KEY = "hackTheWorld_save_list";

function addLog(text) {
    const entry = document.createElement("div");
    entry.textContent = `> ${text}`;
    consoleLog.prepend(entry);
}

// Sauvegarde l'état du jeu dans le state PARTAGÉ (lu par skill_tree.js).
// N'écrase jamais les cryptos/skills, qui appartiennent à l'autre page.
function persistState() {
    let upgradesSave = {};
    for (let key in upgrades) upgradesSave[key] = { count: upgrades[key].count };
    GameState.save({
        totalBytes,
        bytesPerClick,
        clickUpgradeCost,
        clickUpgradeCount,
        upgrades: upgradesSave
    });
}

function getBulkCost(item, amount) {
    const bonuses = SkillTree.getBonuses();
    let cost = 0;
    for (let i = 0; i < amount; i++) {
        cost += Math.floor(item.baseCost * Math.pow(item.costMultiplier, item.count + i) * bonuses.costMult);
    }
    return cost;
}

// Production passive = base des scripts/virus installés, modifiée par:
// - miningSpeed (Trading Bot V1: +20%)
// - passiveMult (Validateur Solana: x2)
// - globalMult (Bloc Genesis: x10, s'applique à TOUS les gains)
function calculateBPS() {
    let baseBps = 0;
    for (let key in upgrades) {
        baseBps += upgrades[key].count * upgrades[key].power;
    }
    const bonuses = SkillTree.getBonuses();
    bytesPerSecond = Math.floor(baseBps * bonuses.miningSpeedMult * bonuses.passiveMult * bonuses.globalMult);
}

function updateUI() {
    dataCounterDisplay.textContent = formatBytes(totalBytes);
    bpsCounterDisplay.textContent = formatBytes(bytesPerSecond);

    upgradeClickButton.querySelector("span:first-child").textContent = `UPGRADE: CPU Overclock (${clickUpgradeCount})`;
    clickUpgradeCostDisplay.textContent = `Cost: ${formatBytes(clickUpgradeCost)}`;

    for (let key in upgrades) {
        const btn = document.getElementById(upgrades[key].id);
        if (btn) {
            const cost = getBulkCost(upgrades[key], buyMultiplier);
            btn.innerHTML = `<span>INSTALL: ${upgrades[key].label} (${upgrades[key].count})</span><span class="price-tag">Cost (x${buyMultiplier}): ${formatBytes(cost)}</span>`;
        }
    }
}

[1, 10, 100].forEach(amt => {
    document.getElementById(`mult-${amt}`).addEventListener("click", (e) => {
        buyMultiplier = amt;
        document.querySelectorAll(".multiplier-bar button").forEach(b => b.classList.remove("active-multiplier"));
        e.target.classList.add("active-multiplier");
        updateUI();
    });
});

clickButton.addEventListener("click", () => {
    // Bloc Genesis (globalMult) s'applique aussi au clic manuel, pas seulement au passif.
    const bonuses = SkillTree.getBonuses();
    const gain = Math.max(1, Math.round(bytesPerClick * bonuses.globalMult));
    totalBytes += gain;
    dataCounterDisplay.textContent = formatBytes(totalBytes);
    persistState();
});

upgradeClickButton.addEventListener("click", () => {
    if (totalBytes >= clickUpgradeCost) {
        totalBytes -= clickUpgradeCost;
        clickUpgradeCount++;
        bytesPerClick = bytesPerClick * 2;
        clickUpgradeCost = Math.floor(clickUpgradeCost * 2.5);
        addLog(`CPU Overclocked to Level ${clickUpgradeCount}. Multiplier doubled.`);
        updateUI();
        persistState();
    }
});

function setupShop() {
    for (let key in upgrades) {
        const btn = document.getElementById(upgrades[key].id);
        if (btn) {
            btn.addEventListener("click", () => {
                const cost = getBulkCost(upgrades[key], buyMultiplier);
                if (totalBytes >= cost) {
                    totalBytes -= cost;
                    upgrades[key].count += buyMultiplier;
                    upgrades[key].cost = getBulkCost(upgrades[key], 1);
                    calculateBPS();
                    addLog(`Deployed ${buyMultiplier}x ${upgrades[key].label}. Yield increased.`);
                    updateUI();
                    persistState();
                }
            });
        }
    }
}

function updateSaveDropdown() {
    saveSelect.innerHTML = '<option value="">-- Select a file --</option>';
    const saveList = getSaveList();
    saveList.forEach(saveName => {
        const option = document.createElement("option");
        option.value = saveName;
        option.textContent = saveName;
        saveSelect.appendChild(option);
    });
}

function getSaveList() {
    const listJson = localStorage.getItem(SAVE_LIST_KEY);
    return listJson ? JSON.parse(listJson) : [];
}

// Les sauvegardes nommées capturent maintenant AUSSI les cryptos et les compétences,
// pour ne pas perdre la progression de l'arbre de compétences en changeant de save.
function saveGame() {
    let name = saveNameInput.value.trim();
    if (name === "") {
        alert("Error: Please enter a valid name.");
        return;
    }
    let upgradesSave = {};
    for (let key in upgrades) {
        upgradesSave[key] = { count: upgrades[key].count };
    }
    const liveState = GameState.load();
    const gameState = {
        totalBytes: totalBytes,
        bytesPerClick: bytesPerClick,
        clickUpgradeCost: clickUpgradeCost,
        clickUpgradeCount: clickUpgradeCount,
        upgrades: upgradesSave,
        currencies: liveState.currencies,
        skills: liveState.skills
    };
    localStorage.setItem("htw_save_" + name, JSON.stringify(gameState));
    const saveList = getSaveList();
    if (!saveList.includes(name)) {
        saveList.push(name);
        localStorage.setItem(SAVE_LIST_KEY, JSON.stringify(saveList));
    }
    addLog(`System state "${name}" saved.`);
    saveNameInput.value = "";
    updateSaveDropdown();
}

function loadGame() {
    const selectedName = saveSelect.value;
    if (!selectedName) return;
    const savedData = localStorage.getItem("htw_save_" + selectedName);
    if (savedData) {
        const gameState = JSON.parse(savedData);
        totalBytes = gameState.totalBytes;
        bytesPerClick = gameState.bytesPerClick || 1;
        clickUpgradeCost = gameState.clickUpgradeCost || 50;
        clickUpgradeCount = gameState.clickUpgradeCount || 0;
        let upgradesSave = {};
        if (gameState.upgrades) {
            for (let key in upgrades) {
                if (gameState.upgrades[key]) {
                    upgrades[key].count = gameState.upgrades[key].count || 0;
                    upgrades[key].cost = getBulkCost(upgrades[key], 1);
                }
                upgradesSave[key] = { count: upgrades[key].count };
            }
        }
        // Réécrit le state PARTAGÉ pour que la page skill_tree.html reflète
        // aussi les cryptos/compétences de cette sauvegarde une fois qu'on y navigue.
        GameState.save({
            totalBytes,
            bytesPerClick,
            clickUpgradeCost,
            clickUpgradeCount,
            upgrades: upgradesSave,
            currencies: gameState.currencies || { tether: 0, solana: 0, ethereum: 0, bitcoin: 0 },
            skills: gameState.skills || {}
        });
        calculateBPS();
        updateUI();
        addLog(`System state "${selectedName}" loaded.`);
    }
}

function wipeAllSaves() {
    if (confirm("Delete ALL saves?")) {
        getSaveList().forEach(name => localStorage.removeItem("htw_save_" + name));
        localStorage.removeItem(SAVE_LIST_KEY);
        updateSaveDropdown();
        addLog("All matrix saves wiped.");
    }
}

saveButton.addEventListener("click", saveGame);
loadButton.addEventListener("click", loadGame);
resetButton.addEventListener("click", wipeAllSaves);

setupShop();
window.addEventListener("load", () => {
    const state = GameState.load();
    totalBytes = state.totalBytes;
    bytesPerClick = state.bytesPerClick;
    clickUpgradeCost = state.clickUpgradeCost;
    clickUpgradeCount = state.clickUpgradeCount;
    for (let key in upgrades) {
        if (state.upgrades[key]) {
            upgrades[key].count = state.upgrades[key].count || 0;
            upgrades[key].cost = getBulkCost(upgrades[key], 1);
        }
    }
    calculateBPS();
    updateSaveDropdown();
    updateUI();
});

setInterval(() => {
    calculateBPS(); // recalcule au cas où un bonus a été débloqué sur l'autre page entre-temps
    bpsCounterDisplay.textContent = formatBytes(bytesPerSecond);
    if (bytesPerSecond > 0) {
        totalBytes += bytesPerSecond;
        dataCounterDisplay.textContent = formatBytes(totalBytes);
    }
    persistState();
}, 1000);
