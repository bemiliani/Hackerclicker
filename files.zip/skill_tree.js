// Version V3.0 - Multi-Currency & Upgrade Skill Tree System (branché sur le state partagé)
const SkillTree = {
    currencies: { tether: 0, solana: 0, ethereum: 0, bitcoin: 0 },
    totalBytes: 0,

    // Tier 1: Tether contre des bytes uniquement
    // Tier 2: Solana contre des bytes + 10 Tether
    // Tier 3: Ethereum contre des bytes + 10 Solana
    // Tier 4: Bitcoin contre des bytes + 10 Ethereum
    cryptoRates: {
        tether:   { byteCost: 1000,      reqCrypto: null,       reqAmount: 0  },
        solana:   { byteCost: 25000,     reqCrypto: "tether",   reqAmount: 10 },
        ethereum: { byteCost: 500000,    reqCrypto: "solana",   reqAmount: 10 },
        bitcoin:  { byteCost: 10000000,  reqCrypto: "ethereum", reqAmount: 10 }
    },

    // Chaque nœud a un "effect" typé, lu par Game.js via getBonuses().
    nodes: {
        usdt_overclock:     { id: "usdt_overclock",     name: "Trading Bot V1",          tier: 1, currency: "tether",   cost: 5, effect: { type: "miningSpeed", value: 0.20 }, description: "Boost la vitesse de minage (production passive) de 20%.", unlocked: false, req: null },
        sol_validator:      { id: "sol_validator",      name: "Validateur Solana",       tier: 2, currency: "solana",   cost: 3, effect: { type: "passiveMult", value: 2 },    description: "Double le revenu passif (bytes/s).", unlocked: false, req: "usdt_overclock" },
        eth_smart_contract: { id: "eth_smart_contract", name: "Smart Contracts Avancés", tier: 3, currency: "ethereum", cost: 2, effect: { type: "costReduction", value: 0.30 }, description: "Réduit les coûts du shop (virus) de 30%.", unlocked: false, req: "sol_validator" },
        btc_genesis_block:  { id: "btc_genesis_block",  name: "Bloc Genesis",            tier: 4, currency: "bitcoin",  cost: 1, effect: { type: "globalMult", value: 10 },    description: "Multiplie tous vos gains globaux (clic + passif) par 10.", unlocked: false, req: "eth_smart_contract" }
    },

    // Recharge tout depuis le state partagé (bytes, cryptos, nœuds débloqués).
    load() {
        const state = GameState.load();
        this.totalBytes = state.totalBytes || 0;
        this.currencies = Object.assign({ tether: 0, solana: 0, ethereum: 0, bitcoin: 0 }, state.currencies || {});
        for (let key in this.nodes) {
            this.nodes[key].unlocked = !!(state.skills && state.skills[key]);
        }
    },

    // Écrit uniquement les champs qui appartiennent à l'arbre de compétences
    // (bytes, cryptos, skills) sans toucher au reste de la sauvegarde du jeu.
    persist() {
        const skillsSnapshot = {};
        for (let key in this.nodes) skillsSnapshot[key] = this.nodes[key].unlocked;
        GameState.save({
            totalBytes: this.totalBytes,
            currencies: this.currencies,
            skills: skillsSnapshot
        });
    },

    buyCrypto(cryptoType) {
        this.load();
        const rate = this.cryptoRates[cryptoType];
        if (!rate) return { success: false, message: "Crypto inconnue." };
        if (this.totalBytes < rate.byteCost) return { success: false, message: "Bytes insuffisants !" };
        if (rate.reqCrypto && (this.currencies[rate.reqCrypto] || 0) < rate.reqAmount) {
            return { success: false, message: `Requis : ${rate.reqAmount} ${rate.reqCrypto.toUpperCase()}` };
        }

        this.totalBytes -= rate.byteCost;
        if (rate.reqCrypto) this.currencies[rate.reqCrypto] -= rate.reqAmount;
        this.currencies[cryptoType] = (this.currencies[cryptoType] || 0) + 1;

        this.persist();
        return { success: true, message: `1 ${cryptoType.toUpperCase()} acheté !` };
    },

    buySkill(nodeId) {
        this.load();
        const node = this.nodes[nodeId];
        if (!node || node.unlocked) return { success: false, message: "Compétence déjà débloquée ou introuvable." };
        if (node.req && !this.nodes[node.req].unlocked) return { success: false, message: "Prérequis non débloqué." };
        if ((this.currencies[node.currency] || 0) < node.cost) return { success: false, message: `Fonds insuffisants en ${node.currency.toUpperCase()}` };

        this.currencies[node.currency] -= node.cost;
        node.unlocked = true;
        this.persist();
        return { success: true, message: `Amélioration ${node.name} activée !` };
    },

    // Utilisé par Game.js à chaque calcul de production/coût pour savoir quels bonus sont actifs.
    getBonuses() {
        this.load();
        let miningSpeedMult = 1, passiveMult = 1, costMult = 1, globalMult = 1;
        for (let key in this.nodes) {
            const n = this.nodes[key];
            if (!n.unlocked) continue;
            switch (n.effect.type) {
                case "miningSpeed": miningSpeedMult *= (1 + n.effect.value); break;
                case "passiveMult": passiveMult *= n.effect.value; break;
                case "costReduction": costMult *= (1 - n.effect.value); break;
                case "globalMult": globalMult *= n.effect.value; break;
            }
        }
        return { miningSpeedMult, passiveMult, costMult, globalMult };
    }
};

SkillTree.load();
